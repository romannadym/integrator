import { getCookie } from './cookies.js';
document.addEventListener('DOMContentLoaded', function(){
  let equipment = document.getElementById('id_equipment'),
    csrftoken = getCookie('csrftoken'),
    contacts = document.getElementById('id_contact'),
    datalist = equipment.list;

  function SNCheck(){
    var optionFound = false,
      datalist = equipment.list,
      options = datalist.options;

    for(let option of options){
      if(equipment.value === option.value){
        optionFound = true;
        break;
      }
    }

    if(!optionFound){
      equipment.setCustomValidity('Выбрано неверное значение');
      equipment.reportValidity();
      return false;
    }
    return true;
  }

  function EquipmentList(){
    let options = datalist.options,
      client = document.getElementById("id_client").value;

    for(let option of options){
      if(equipment.value === option.value){
        return;
      }
    }
    datalist.innerHTML = '';
    let confs = document.querySelectorAll('#confs p');
    for(let p of confs){
      p.remove();
    }

    if(equipment.value && client){
      // console.log(datalist.options.namedItem(equipment.value));
      let fData = new FormData();
      console.log('sdsd') 
      fData.append('client', client);
      fData.append('sn', equipment.value);

      fetch('.', {
        method: 'POST',
        credentials: 'same-origin',
        headers:{
            'Accept': 'application/json',
            'X-CSRFToken': csrftoken,
  		  },
  		      body: fData
  		  })
        .then(response => {
            return response.json();
        })
        .then(result => {
          for(let eq of result){
            let option = document.createElement('option');
            option.value = eq.equipment__brand__name + ' ' + eq.equipment__model__name + ' (S/n: ' + eq.sn + ')';
            // option.value = eq.sn;
            // option.text = eq.equipment__brand__name + ' ' + eq.equipment__model__name;
            datalist.appendChild(option);
            if(eq.conf){
              document.querySelector('#confs label').insertAdjacentHTML("afterend", eq.conf);
            }
          }
        })
        .catch(error => {
            console.log(error);
        });
    }
  }

  equipment.addEventListener('input', function(){
    EquipmentList();
  });
  equipment.addEventListener('change', function(){
    EquipmentList();

    if(this.value != ''){
      let eq_check = SNCheck();
      if(!eq_check){
        return;
      }
    }
  });



  let add_doc = document.getElementById('add-doc'),
    del_btns = document.querySelectorAll('.delete-item');

  if(typeof(del_btns) != 'undefined' && del_btns != null){
    for(let btn of del_btns){
      btn.addEventListener('click', function(){
        btn.closest('p').querySelector('input[type=checkbox]').checked = true;
        btn.closest('p').classList.add('hidden');
      });
    }
  }

  add_doc.addEventListener('click', function(){
    let total = add_doc.closest('form').querySelectorAll('input[id^=id_documents-][id$=-DELETE]').length,
    newF = document.querySelector('.empty-doc').cloneNode(true),
    prefix = 'documents-' + total,
    new_formset;

    newF.innerHTML = newF.innerHTML.replace(/documents-__prefix__/g, 'documents-' + total);

    // if(total > 0){
    //   add_doc.closest('div').after(new_formset);
    // }
    // else{
    //   new_formset = newF.querySelector('.formset');
    //   document.getElementById('doc_formsets').appendChild(new_formset);
    // }
    new_formset = newF.querySelector('p');
    add_doc.closest('div').before(new_formset);
    total++;

    document.getElementById('id_documents-TOTAL_FORMS').value = total;
    let btn = new_formset.querySelector('.delete-item')
    btn.addEventListener('click', function(){
      btn.closest('p').querySelector('input[type=checkbox]').checked = true;
      btn.closest('p').classList.add('hidden');
    });
  });

  let client = document.getElementById('id_client');
  if(typeof(client) != 'undefined' && client != null){
    client.addEventListener('change', function(){
        datalist.innerHTML = '';
        contacts.innerHTML = '<option value="" selected="">---------</option>';
        equipment.value = '';

        if(client.value){
          let fData = new FormData();
          fData.append('client', client.value);

          fetch('../get_contacts/', {
            method: 'POST',
            credentials: 'same-origin',
            headers:{
                'Accept': 'application/json',
                'X-CSRFToken': csrftoken,
      		  },
      		      body: fData
      		  })
            .then(response => {
                return response.json();
            })
            .then(result => {
              for(let contact of result){
                let option = document.createElement('option');
                option.value = contact.id;
                option.text = contact.fio;
                contacts.appendChild(option);
              }
            })
            .catch(error => {
                console.log(error);
            });

            EquipmentList(); //Обновляем список оборудования
        }
    });
  }

  let form = document.getElementById('app-form'),
    modal = document.getElementById("modal"),
    modal_close = document.getElementById("modal-close"),
    modal_text = modal.querySelector('.modal-text');

  modal_close.addEventListener('click', function(){
    modal.style.display = "none";
  });

  form.addEventListener('submit', function(evn){
    evn.preventDefault();
    let docs = document.querySelectorAll('input[id^=id_documents-][id$=-document]'),
      files_size = 0,
      btn_submit = form.querySelector('button[type=submit]');
      modal_text.classList.remove('green-text');

    btn_submit.disabled = true;
    modal_text.innerHTML = '';

    for(let doc of docs){
      if(!doc.closest('p').querySelector('input[id^=id_documents-][id$=-DELETE]').checked && doc.files.length > 0){
        files_size += doc.files[0].size;
      }
    }

    if(files_size > 52428800){
      modal_text.innerHTML = '<p>Размер файлов превышает 50 Мб!</p>';
      modal.style.display = "block";

      return;
    }
    let eq_check = SNCheck();
    if(!eq_check){
      return;
    }

    let fData = new FormData(form);

    fetch('.', { 
      method: 'POST',
      credentials: 'same-origin',
      headers:{
          'Accept': 'application/json',
          'X-CSRFToken': csrftoken,
		  },
		      body: fData
		  })
		  .then(response => {
		    return response.json();
		  })
		  .then(data => {
        if(data['message'] == 1){
          modal_text.classList.add('green-text');
          modal_text.innerHTML = '<p class="align-center">Заявка принята в работу. Спасибо, что Вы с нами!</p><p class="align-center">С уважением, команда xCloud</p>';
          modal.style.display = "block";
          modal_close.addEventListener('click', function(){
            window.location.replace(document.getElementById("back").value);
          });
        }
        else{
          error_text = '';
          for(let field in data){
            error_text += '<p>"' + field + '" - ' + data[field][0] + '</p>';
          }
          modal_text.innerHTML = error_text;
          modal.style.display = "block";
          btn_submit.disabled = false;
        }
		  })
			.catch(error => {
        console.error('Error:', error);
        // btn_submit.disabled = false;
		  });
  });
});
